from datetime import datetime, timedelta
import requests
import csv
import psycopg2
import yfinance as yf
import re
from airflow import DAG
from airflow.operators.python import PythonOperator

# Default arguments for the DAG
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2025, 5, 1),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

# Define the DAG
dag = DAG(
    'hackernews_analysis',
    default_args=default_args,
    description='Fetch Hacker News stories, analyze MAANG mentions and GitHub repos',
    schedule_interval=timedelta(days=1),
    catchup=False
)

# PostgreSQL connection info (matches docker-compose)
POSTGRES_CONN_INFO = {
    'host': 'postgres',
    'database': 'airflow',
    'user': 'airflow',
    'password': 'airflow',
    'port': 5432
}

# MAANG company mappings
MAANG_COMPANIES = {
    'AMZN': ['amazon', 'aws'],
    'AAPL': ['apple', 'mac', 'iphone', 'ipad'],
    'NFLX': ['netflix'],
    'GOOGL': ['google', 'alphabet'],
    'META': ['meta', 'facebook'],
}

# GitHub API settings (add your token if you have one)
GITHUB_TOKEN = None
GITHUB_HEADERS = {
    'Accept': 'application/vnd.github.v3+json'
}
if GITHUB_TOKEN:
    GITHUB_HEADERS['Authorization'] = f'token {GITHUB_TOKEN}'


def fetch_stories():
    """Fetch top stories from Hacker News API"""
    # Get top story IDs
    response = requests.get('https://hacker-news.firebaseio.com/v0/topstories.json')
    story_ids = response.json()[:10]  # Get first 500 stories

    stories = []
    for story_id in story_ids:
        # Get story details
        item_response = requests.get(f'https://hacker-news.firebaseio.com/v0/item/{story_id}.json')
        item = item_response.json()

        # Only include stories with title and type=story
        if item.get('type') == 'story' and item.get('title'):
            stories.append({
                'id': story_id,
                'title': item['title'],
                'author': item.get('by', 'unknown'),
                'created_at': datetime.fromtimestamp(item['time']),
                'url': item.get('url', '')
            })

    # Save to CSV
    with open('/opt/airflow/dataset/hn_stories.csv', 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=['id', 'title', 'author', 'created_at', 'url'])
        writer.writeheader()
        writer.writerows(stories)

    return stories


def load_to_postgres():
    """Load stories from CSV to PostgreSQL"""
    conn = psycopg2.connect(**POSTGRES_CONN_INFO)
    cursor = conn.cursor()

    # Create table if not exists
    cursor.execute("""
                   CREATE TABLE IF NOT EXISTS hn_stories
                   (
                       id
                       BIGINT
                       PRIMARY
                       KEY,
                       title
                       TEXT,
                       author
                       TEXT,
                       created_at
                       TIMESTAMP,
                       url
                       TEXT
                   );
                   """)

    # Clear existing data
    cursor.execute("TRUNCATE TABLE hn_stories;")

    # Load data from CSV
    with open('/opt/airflow/dataset/hn_stories.csv', 'r') as f:
        cursor.copy_expert("""
            COPY hn_stories FROM STDIN WITH CSV HEADER
        """, f)

    conn.commit()
    cursor.close()
    conn.close()


def analyze_maang_mentions():
    """Analyze MAANG company mentions and fetch stock prices"""
    # Read Hacker News stories
    with open('/opt/airflow/dataset/hn_stories.csv', 'r') as f:
        reader = csv.DictReader(f)
        stories = list(reader)

    # Define company mappings with display names
    COMPANY_DISPLAY_NAMES = {
        'AMZN': 'AMAZON',
        'AAPL': 'APPLE',
        'NFLX': 'NETFLIX',
        'GOOGL': 'GOOGLE',
        'META': 'META'
    }

    # Process each story to find MAANG mentions
    mention_data = {}
    for story in stories:
        date = datetime.strptime(story['created_at'], '%Y-%m-%d %H:%M:%S').date()
        title = story['title'].lower()

        if date not in mention_data:
            mention_data[date] = {f'{COMPANY_DISPLAY_NAMES[ticker]}_Mentions': 0 for ticker in MAANG_COMPANIES}

        for ticker, keywords in MAANG_COMPANIES.items():
            if any(keyword in title for keyword in keywords):
                mention_data[date][f'{COMPANY_DISPLAY_NAMES[ticker]}_Mentions'] += 1

    # Get stock prices for each date with mentions
    tickers = list(MAANG_COMPANIES.keys())
    start_date = min(mention_data.keys()) if mention_data else datetime.today().date()
    end_date = max(mention_data.keys()) if mention_data else datetime.today().date()

    stock_data = yf.download(tickers, start=start_date, end=end_date + timedelta(days=1), interval='1d')

    # Combine mention and stock data
    combined_data = []
    for date, mentions in mention_data.items():
        row = {'date': date.strftime('%Y-%m-%d')}

        # Add stock prices
        for ticker in tickers:
            display_name = COMPANY_DISPLAY_NAMES[ticker]
            try:
                price = stock_data['Close'][ticker].loc[date.strftime('%Y-%m-%d')]
                row[f'{display_name}_Price'] = round(float(price), 2)
            except (KeyError, IndexError):
                row[f'{display_name}_Price'] = None

        # Add mentions
        row.update(mentions)
        combined_data.append(row)

    # Save to CSV
    with open('/opt/airflow/dataset/company_prices_and_mentions.csv', 'w', newline='') as f:
        fieldnames = ['date'] + \
                     [f'{COMPANY_DISPLAY_NAMES[ticker]}_Price' for ticker in tickers] + \
                     [f'{COMPANY_DISPLAY_NAMES[ticker]}_Mentions' for ticker in tickers]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(combined_data)

def extract_github_stats():
    """Extract GitHub repo URLs and fetch their statistics"""
    # Read Hacker News stories
    with open('/opt/airflow/dataset/hn_stories.csv', 'r') as f:
        reader = csv.DictReader(f)
        stories = list(reader)

    # Extract GitHub URLs and repo paths
    github_repos = []
    github_pattern = re.compile(r'https?://github\.com/([^/]+/[^/]+)/?')

    for story in stories:
        if not story['url']:
            continue

        match = github_pattern.search(story['url'])
        if match:
            repo_path = match.group(1)
            github_repos.append({
                'id': story['id'],
                'title': story['title'],
                'author': story['author'],
                'url': story['url'],
                'repo_path': repo_path
            })

    # Fetch GitHub stats for each repo
    for repo in github_repos:
        try:
            url = f"https://api.github.com/repos/{repo['repo_path']}"
            response = requests.get(url, headers=GITHUB_HEADERS)
            if response.status_code == 200:
                data = response.json()
                repo.update({
                    'stars': data.get('stargazers_count'),
                    'forks': data.get('forks_count'),
                    'issues': data.get('open_issues_count'),
                    'watchers': data.get('subscribers_count')
                })
            else:
                repo.update({
                    'stars': None,
                    'forks': None,
                    'issues': None,
                    'watchers': None
                })
        except Exception as e:
            print(f"Error fetching GitHub data for {repo['repo_path']}: {e}")
            repo.update({
                'stars': None,
                'forks': None,
                'issues': None,
                'watchers': None
            })

    # Save to CSV
    with open('/opt/airflow/dataset/github_stats.csv', 'w', newline='') as f:
        fieldnames = ['id', 'title', 'author', 'url', 'repo_path', 'stars', 'forks', 'issues', 'watchers']
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(github_repos)


# Define tasks
fetch_task = PythonOperator(
    task_id='fetch_stories',
    python_callable=fetch_stories,
    dag=dag
)

load_task = PythonOperator(
    task_id='load_to_postgres',
    python_callable=load_to_postgres,
    dag=dag
)

maang_task = PythonOperator(
    task_id='analyze_maang_mentions',
    python_callable=analyze_maang_mentions,
    dag=dag
)

github_task = PythonOperator(
    task_id='extract_github_stats',
    python_callable=extract_github_stats,
    dag=dag
)

# Set task dependencies
fetch_task >> load_task
fetch_task >> maang_task
fetch_task >> github_task