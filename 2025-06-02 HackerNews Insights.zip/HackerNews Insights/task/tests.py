import os
from test.tests import TechWordsCsvTest

if __name__ == '__main__':
    TechWordsCsvTest().run_tests()