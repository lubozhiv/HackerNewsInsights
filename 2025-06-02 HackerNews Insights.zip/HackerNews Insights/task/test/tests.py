import os
import pandas as pd
from hstest import StageTest, TestCase, CheckResult

class TechWordsCsvTest(StageTest):

    def generate(self):
        return [TestCase(time_limit=1000000)]

    def check(self, reply: str, attach) -> CheckResult:
        file_path = 'dataset/tech_words.csv'

        if not os.path.exists(file_path):
            return CheckResult.wrong(
                f'CSV file not found at `{file_path}`.\n'
                f'Please ensure the tech words data is saved correctly.')

        try:
            df = pd.read_csv(file_path)
        except Exception as e:
            return CheckResult.wrong(f'Failed to read CSV file due to error:\n{e}')

        required_columns = ['word', 'count']
        if list(df.columns) != required_columns:
            return CheckResult.wrong(
                f'CSV columns must be exactly {required_columns}\n'
                f'But found: {list(df.columns)}')

        if df.empty:
            return CheckResult.wrong('CSV file is empty. Please ensure data is saved.')

        try:
            assert df['word'].apply(lambda x: isinstance(x, str)).all(), 'All "word" entries must be strings'
            assert pd.api.types.is_integer_dtype(df['count']) or all(df['count'].dropna().apply(float.is_integer)), \
                '"count" column must contain integers'
            assert (df['count'] >= 0).all(), '"count" values must be non-negative'
        except Exception as e:
            return CheckResult.wrong(f'Data type or value validation failed:\n{e}')

        return CheckResult.correct()


class CommentsAnalysisCsvTest(StageTest):

    def generate(self):
        return [TestCase(time_limit=1000000)]

    def check(self, reply: str, attach) -> CheckResult:
        file_path = 'dataset/comments_analysis.csv'

        if not os.path.exists(file_path):
            return CheckResult.wrong(
                f'CSV file not found at `{file_path}`.\n'
                f'Please ensure comments analysis data is saved correctly.')

        try:
            df = pd.read_csv(file_path)
        except Exception as e:
            return CheckResult.wrong(f'Failed to read CSV file due to error:\n{e}')

        required_columns = ['id', 'author', 'text', 'processed_text', 'sentiment']
        if list(df.columns) != required_columns:
            return CheckResult.wrong(
                f'CSV columns must be exactly {required_columns}\n'
                f'But found: {list(df.columns)}')

        if df.empty:
            return CheckResult.wrong('CSV file is empty. Please ensure data is saved.')

        try:
            assert df['id'].apply(lambda x: str(x).isdigit()).all(), '"id" must be numeric'
            assert df['author'].apply(lambda x: isinstance(x, str)).all(), '"author" must be string'
            assert df['text'].apply(lambda x: isinstance(x, str)).all(), '"text" must be string'
            assert df['processed_text'].apply(lambda x: isinstance(x, str)).all(), '"processed_text" must be string'
            allowed_sentiments = {'positive', 'negative', 'neutral'}
            invalid_sentiments = set(df['sentiment'].unique()) - allowed_sentiments
            if invalid_sentiments:
                return CheckResult.wrong(
                    f'Sentiment column contains invalid values: {invalid_sentiments}. '
                    f'Allowed: {allowed_sentiments}')
        except Exception as e:
            return CheckResult.wrong(f'Data type or value validation failed:\n{e}')

        return CheckResult.correct()


if __name__ == '__main__':
    TechWordsCsvTest().run_tests()
    CommentsAnalysisCsvTest().run_tests()